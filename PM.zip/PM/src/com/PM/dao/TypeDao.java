package com.PM.dao;

import java.util.ArrayList;

import com.PM.bean.Type;

public interface TypeDao {
   void delete(Type type);
   Type selectById(int id);
   ArrayList<Type> selectAll();
   void update(Type type);
}
