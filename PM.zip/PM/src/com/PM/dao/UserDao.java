package com.PM.dao;

import com.PM.bean.User;

public interface UserDao {
	User selectByName(String name);
	void insert(User user);
}
