package com.PM.dao.impl;

import java.util.ArrayList;

import com.PM.bean.Product;
import com.PM.dao.ProductDao;
import com.PM.mapper.impl.ProductMapper;
import com.PM.util.JdbcUtil;

public class ProductDaoImpl implements ProductDao{
	
	@Override
	public void update(Product product) {
		String sql="update product set pcount=? where pid=?";
		JdbcUtil.update(sql, product.getCount(),product.getId());
		System.out.println("�޸ĳɹ�");
	}

	@Override
	public void insert(Product product) {
		String sql="insert into product values(?,?,?,?,?)";
		int n=JdbcUtil.update(sql,product.getId(),product.getName(),product.getPrice(),product.getCount(),product.getTid());
		System.out.println("���ӳɹ�,Ӱ������: "+n);
	}

	@Override
	public Product selectById(int id) {
		String sql="select * from product where pid=?";
		Product product=(Product) JdbcUtil.select(sql, new ProductMapper() , id);
		return product;
	}

	@Override
	public ArrayList<Product> selectAll() {
		String sql="select * from product where pid>=?";
		ArrayList<Product> list=JdbcUtil.selectList(sql, new ProductMapper(),1);
		return list;
	}

	@Override
	public void delete(int id){
		String sql="delete * from where pid=?";
		JdbcUtil.update(sql, id);
	}

	@Override
	public Product selectByName(String name) {
		String sql="select * from product where pname=?";
		Product product=(Product) JdbcUtil.select(sql, new ProductMapper(), name);
		return product;
	}
}
