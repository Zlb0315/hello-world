package com.PM.dao.impl;

import java.util.ArrayList;

import com.PM.bean.Type;
import com.PM.dao.TypeDao;
import com.PM.mapper.impl.TypeMapper;
import com.PM.util.JdbcUtil;

public class TypeDaoImpl implements TypeDao {

	@Override
	public void delete(Type type) {
		
		
	}
	@Override
	public Type selectById(int id) {
		String sql="select  * from ptype where tid=?";
		Type type=(Type) JdbcUtil.select(sql,new TypeMapper(), id);
		return type;
	}

	@Override
	public ArrayList<Type> selectAll() {
		
		return null;
	}

	@Override
	public void update(Type type) {
		
		
	}

}
