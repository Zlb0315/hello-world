package com.PM.dao.impl;

import com.PM.bean.User;
import com.PM.dao.UserDao;
import com.PM.mapper.impl.UserMapper;
import com.PM.util.JdbcUtil;

public class UserDaoImpl implements UserDao {
	@Override
	public User selectByName(String name) {
		String sql="select * from duser where uname=?";
		User user=(User) JdbcUtil.select(sql, new UserMapper(), name);
		return user;
	}

	@Override
	public void insert(User user) {
		String sql="insert into duser values(?,?,?)";
		JdbcUtil.update(sql, user.getId(),user.getName(),user.getPassword());
		
	}

}
