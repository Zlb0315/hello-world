package com.PM.mapper;

import java.sql.ResultSet;

public interface Mapper {
 
	public Object rowMapper(ResultSet rs) throws Exception;
	
}
