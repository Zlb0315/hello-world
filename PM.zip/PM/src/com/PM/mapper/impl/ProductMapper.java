package com.PM.mapper.impl;

import java.sql.ResultSet;

import com.PM.bean.Product;
import com.PM.mapper.Mapper;

public class ProductMapper implements Mapper{
	@Override
	public Object rowMapper(ResultSet rs) throws Exception {
		Product product=new Product();
		product.setId(rs.getInt("pid"));
		product.setName(rs.getString("pname"));
		product.setPrice(rs.getDouble("price"));
		product.setCount(rs.getInt("pcount"));
		product.setTid(rs.getInt("tid"));
		return product;
	}

}
