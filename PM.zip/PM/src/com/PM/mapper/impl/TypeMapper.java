package com.PM.mapper.impl;

import java.sql.ResultSet;

import com.PM.bean.Type;
import com.PM.mapper.Mapper;

public class TypeMapper implements Mapper{

	@Override
	public Object rowMapper(ResultSet rs) throws Exception {
		Type type=new Type();
		type.setTid(rs.getInt("tid"));
		type.setTname(rs.getString("tname"));
		return type;
	}

}
