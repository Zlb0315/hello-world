package com.PM.mapper.impl;
import java.sql.ResultSet;
import com.PM.bean.User;
import com.PM.mapper.Mapper;

public class UserMapper implements Mapper{
	@Override
	public Object rowMapper(ResultSet rs) throws Exception {
		User user=new User();
		user.setId(rs.getInt("duid"));
		user.setName(rs.getString("uname"));
		user.setPassword(rs.getString("upassword"));
		return user;
	}
}
