package com.PM.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.PM.mapper.Mapper;

public class JdbcUtil {
	private static Connection con=null;
	private JdbcUtil(){
	}
	static{
		try {
			//ע������
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public  static Connection getCon(){
		if (con==null) {
			try {
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","151630");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return con;
	}
	//����
	public  static int update(String sql,Object ...args){
		PreparedStatement ps=null;
		Connection con=null;
		int n=0;
		try {
			con =JdbcUtil.getCon();
			ps=con.prepareStatement(sql);
			for(int i=0;i<args.length;i++){
				ps.setObject(i+1, args[i]);
			}
			n=ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		} 
		return n;
	}
	//��ѯһ��
	public static Object select(String sql,Mapper mapper,Object ...args){
		Object o=null;
		PreparedStatement ps=null;
		Connection con=null;
		ResultSet rs=null;
		try {
			con=JdbcUtil.getCon();
			ps=con.prepareStatement(sql);
			for (int i = 0; i < args.length; i++) {
				ps.setObject(i+1, args[i]);
			}
			rs=ps.executeQuery();
			try {
				while(rs.next()){
					o=mapper.rowMapper(rs);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return o;
	}
	
	public static ArrayList selectList(String sql,Mapper mapper,Object ...args){
		ArrayList<Object> list=new ArrayList<>();
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			con=JdbcUtil.getCon();
			ps=con.prepareStatement(sql);
			
			for (int i = 0; i < args.length; i++) {
				ps.setObject(i+1, args[i]);
			}
			rs=ps.executeQuery();
			while(rs.next()){
				Object o=mapper.rowMapper(rs);
				list.add(o);
			}
		}catch(Exception e){
			e.printStackTrace();
		}/*finally {
			try {
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		return list;
	}
	//����
	public static void close(){
		if(con!=null)
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	

}
